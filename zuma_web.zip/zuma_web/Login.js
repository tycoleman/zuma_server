// 1. Import Firebase and initialize it
const firebase = require('firebase/app');
require('firebase/auth');

const firebaseConfig = {
  // Your firebase configuration object here
};

firebase.initializeApp(firebaseConfig);

// 2. Get reference to Firebase auth service
const auth = firebase.auth();

// 3. Set up reCAPTCHA verifier
window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('sign-in-button', {
  'size': 'invisible',
  'callback': function(response) {
    // reCAPTCHA solved, allow signInWithPhoneNumber.
    onSignInSubmit();
  }
});

// 4. Trigger SMS authentication
function onSignInSubmit() {
  const phoneNumber = getPhoneNumberFromUserInput();
  const appVerifier = window.recaptchaVerifier;
  
  auth.signInWithPhoneNumber(phoneNumber, appVerifier)
    .then((confirmationResult) => {
      window.confirmationResult = confirmationResult;
      console.log('SMS sent!');
    }).catch((error) => {
      console.log('SMS not sent', error);
    });
}

// 5. Once SMS is received, user types it in and we verify it
function onConfirmationCodeSubmit() {
  const code = getCodeFromUserInput();
  
  confirmationResult.confirm(code).then((result) => {
    const user = result.user;
    console.log('User signed in successfully!');
  }).catch((error) => {
    console.log('User could not sign in', error);
  });
}